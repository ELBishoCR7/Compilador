/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package compiladorfinal;

/**
 *
 * @author gmva2
 */
public enum Tokens {
    Reservadas,
    Igual,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    id,
    num,
    cadena,
    mayor,
    menor,
    or,
    and,
    not,
    punto,
    punto_coma,
    dos_puntos,
    Flotante,
    caracter,
    Entero,
    Modulo,
    comilla,
    SaltoLinea,
    parentesisa,
    parentesisc,
    menorigual,
    mayorigual,
    igualdad,
    diferente,
    coma,
    llavea,
    llavec,
    ERROR;

    
}
